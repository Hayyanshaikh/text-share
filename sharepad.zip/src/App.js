import React from 'react';
import Layout from './components/layout/Layout.js';
import './styles/style.css';
// Import Swiper styles
import 'swiper/css';
const App = () => {
  return (
    <>
     <Layout/> 
    </>
  )
}

export default App