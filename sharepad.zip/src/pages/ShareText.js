import React from 'react'

const ShareText = () => {
	return (
		<div>
			ShareText
		</div>
	)
}

export default ShareText