import React from 'react'

const Accordion = () => {
	return (
		<div>
			
		</div>
	)
}

export default Accordion