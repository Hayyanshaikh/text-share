import React from 'react'

const Textarea = () => {
	return (
		<div>
			
		</div>
	)
}

export default Textarea